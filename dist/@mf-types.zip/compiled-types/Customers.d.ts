declare const Customers: () => import("react/jsx-runtime").JSX.Element;
export default Customers;
